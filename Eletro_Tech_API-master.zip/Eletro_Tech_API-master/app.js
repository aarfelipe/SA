const express = require("express");
const cors = require("cors");

const userRouter = require("./src/routes/user");
const employeeRouter = require("./src/routes/employees");
const serviceRouter = require("./src/routes/services");
const scheduleRouter = require("./src/routes/schedules");

const app = express();

app.use(cors());  
app.use(express.urlencoded({extended: true}));
app.use(express.json());

app.use("/users", userRouter);
app.use("/employees", employeeRouter);
app.use("/services", serviceRouter);
app.use("/schedules", scheduleRouter);

module.exports = app;