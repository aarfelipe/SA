async function sync() {
  console.log("\n\n-=-=-=-=-=-=-=-\n\n Sync Database \n\n-=-=-=-=-=-=-=-\n\n");
  const database = require("./src/database");
  await database.sync({force:true});
}

if(process.argv[2] == "--sync") sync();

require("dotenv").config();

const app = require("./app");

app.get("/", (req, res) => {
  res.send("Initial route");
});

const port = 7811;

app.listen(port, () => {
  console.log(`Server is running on port ${port}!`);
});
