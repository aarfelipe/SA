module.exports = {
  host: "eletrotech.cbvrfw71fun0.sa-east-1.rds.amazonaws.com",
  database: "eletro_tech",
  user: "admin",
  password: "Eletro_Tech_BD",
  dialect: "mysql",
  define: {
    timestamps: false
  }
}