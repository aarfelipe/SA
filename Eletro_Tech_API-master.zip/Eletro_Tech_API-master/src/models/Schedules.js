const Sequelize = require("sequelize");
const database = require("../database");

const User = require("../models/User");
const Employee = require("../models/Employee");
const Service = require("../models/Service");

const Schedules = database.define("schedules", {
  id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  date: {
    type: Sequelize.DATE,
    allowNull: false
  },
  time: {
    type: Sequelize.STRING,
    allowNull: false 
  },
  status: {
    type: Sequelize.STRING,
    allowNull: false
  },
});


Employee.hasMany(Schedules, {foreignKey: 'employee_id'});
Schedules.belongsTo(Employee, {foreignKey: 'employee_id'});

Service.hasMany(Schedules, {foreignKey: 'service_id'});
Schedules.belongsTo(Service, {foreignKey: 'service_id'});

module.exports = Schedules;

