const Sequelize = require("sequelize");
const database = require("../database");

const Schedules = require("./Schedules");

const Service = database.define("services", {
  id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true
  },
  name: {   
    type: Sequelize.STRING,
    allowNull: false
  },
  description: {
    type: Sequelize.STRING,
    allowNull: false
  },
  value: {
    type: Sequelize.STRING,
    allowNull: false
  },
  disponibility: {
    type: Sequelize.INTEGER,
    allowNull: false
  }
});



module.exports = Service;