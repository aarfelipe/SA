const bcrypt = require("bcrypt");
const JWT = require("jsonwebtoken");

const Router = require("express").Router();

const Employee = require("../models/Employee");
const { Op } = require("sequelize");

const JWT_SECRET = process.env.JWT_SECRET;

Router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  

  try {
    const data = await Employee.findOne({ where: { 
      [Op.and] : [
        {email},
        {role: "admin"}
      ]
     }});
    if(data) {
      const hash_status = await bcrypt.compare(password, data.password); 
  
      if(hash_status) {
        const token = await JWT.sign(data.id, JWT_SECRET);
        return res.send({token});
      } else {
        res.status(400);
        return  res.send({
          error: "Dados de login invalidos."
        });
      }
    } else {
      res.status(400);
      return  res.send({
        error: "Dados de login invalidos."
      });
    }
  } catch(e) {
      res.status(400);
      return  res.send({
        error: "Dados de login invalidos."
      });
  }

});

Router.get("/", async (req, res) => {
  const userid = req.query.id;

  try {
    const data = await Employee.findAll({attributes: {exclude: ['password']}});
    res.send(data);
  } catch(e) {

      res.status(400);
      return  res.send({
        error: "Houve um problema ao buscar os dados"
      });
  }

});

Router.get("/technicians", async (req, res) => {
  const userid = req.query.id;

  try {
    const data = await Employee.findAll({where: {role: "technician"}, attributes: {exclude: ['password']},});
    res.send(data);
  } catch(e) {

      res.status(400);
      return  res.send({
        error: "Houve um problema ao buscar os dados"
      });
  }

});
Router.put("/:id", async (req, res) => {
  const userid = req.params.id;
  const { username, email, address, role } = req.body;

  try {
    const data = await Employee.findByPk(userid,{attributes: {exclude: ['password']},});

    data.username = username;
    data.email = email;
    data.address = address;
    data.role = role;

    
    data.save();

    res.send(data);
  } catch(e) {
    console.log(e);
      res.status(400);
      return  res.send({
        error: "Houve um problema ao atualizar os dados"
      });
  }

});


// Cadastro
Router.post("/", async (req, res) => {
  const { username, email, password, address, role } = req.body;

  const hash = await bcrypt.hash(password, 10);

  try {
    const data = await Employee.create({
      username,
      email,
      password: hash,
      address,
      role
    });

  
    res.status(200); 

    return res.send({
      username,
      email,
      address,
      role
    }).json();

  } catch(e) {  
    res.status(400);

    return res.send({
      error: "Erro ao realizar cadastro."
    });
  }

});

module.exports = Router;