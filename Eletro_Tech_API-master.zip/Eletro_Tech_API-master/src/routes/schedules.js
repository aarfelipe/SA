const bcrypt = require("bcrypt");
const JWT = require("jsonwebtoken");

const Router = require("express").Router();

const User = require('../models/User');
const Schedules = require('../models/Schedules');
const Service = require('../models/Service');
const Employee = require("../models/Employee");



const JWT_SECRET = process.env.JWT_SECRET;

// GET
Router.get("/", async (req, res) => {
  try {
    const data = await Schedules.findAll({include: [Service, Employee, User]});
    res.send(data);
  } catch(e) {
      res.status(400);
      return  res.send({
        error: "Houve um problema ao buscar os dados"
      });
  }

});




// Cadastro
Router.post("/", async (req, res) => {
  const {address, date, time, user_id, service_id, status } = req.body;

  try {
    const data = await Schedules.create({
      address, 
      date, 
      time, 
      user_id, 
      service_id, 
      status
    });

    res.status(200);

    return res.send({
      address, 
      date, 
      time, 
      user_id, 
      service_id, 
      status
    });

  } catch(e) {
    console.log(e);

    res.status(400);

    return res.send({
      error: "Erro ao criar agendamento."
    });
  }

});
Router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { employee } = req.body;

  try {
    const data = await Schedules.findByPk(id);

    data.employee_id = employee; 

    data.save();
 
    return res.send(data);

  } catch(e) {
    console.log(e);

    res.status(400);

    return res.send({
      error: "Erro ao criar agendamento."
    });
  }

});
Router.post("/:id/payment", async (req, res) => {
  const { id } = req.params;

  try {
    const data = await Schedules.findByPk(id);

    data.status = "Agendado"; 

    data.save();
 
    return res.send(data);

  } catch(e) {
    console.log(e);

    res.status(400);

    return res.send({
      error: "Erro ao receber pagamento."
    });
  }

});

Router.put("/:id/finish", async (req, res) => {
  const { id } = req.params;

  try {
    const data = await Schedules.findByPk(id);

    data.status = "Concluido"; 

    data.save();
 
    return res.send(data);

  } catch(e) {
    console.log(e);

    res.status(400);

    return res.send({
      error: "Erro ao receber pagamento."
    });
  }

});

module.exports = Router;