const Router = require("express").Router();

const Service = require("../models/Service");


// Cadastro de serviço
Router.post("/", async (req, res) => {
    const { name, description, value, disponibility } = req.body;

    try {
        const data = await Service.create({
            name,
            description,
            value,
            disponibility
        });
    
        return res.send(data)
    } catch(e) {
        console.log(e);
        return res.send({
            error: "Houve um problema ao cadastrar o serviço."
        });
    }
  
});
Router.put("/:id", async (req, res) => {
    const { name, description, value, disponibility } = req.body;
    const { id } = req.params;

    try {
        const data = await Service.findByPk(id);
    
        data.name = name;
        data.description = description;
        data.value = value;
        data.disponibility = disponibility;

        data.save();

        return res.send(data)
    } catch(e) {
        return res.send({
            error: "Houve um problema ao atualizar o serviço."
        });
    }
  
});

Router.get("/available", async (req, res) => {
  const data = await Service.findAll({where:{disponibility:1}});

  try {
    if(data) return res.send(data)
    else {
        res.status(400);
        return  res.send({
            error: "Houve um problema ao buscar os dados."
        });
    }
    } catch(e) {
        return  res.send({
            error: "Houve um problema ao buscar os dados."
        });
    }
});
Router.get("/", async (req, res) => {
  const data = await Service.findAll();

  try {
    if(data) return res.send(data)
    else {
        res.status(400);
        return  res.send({
            error: "Houve um problema ao buscar os dados."
        });
    }
    } catch(e) {
        return  res.send({
            error: "Houve um problema ao buscar os dados."
        });
    }
});

module.exports = Router;