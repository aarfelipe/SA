const bcrypt = require("bcrypt");
const JWT = require("jsonwebtoken");

const Router = require("express").Router();

const User = require('../models/User');
const Schedules = require('../models/Schedules');
const Service = require('../models/Service');


const JWT_SECRET = process.env.JWT_SECRET;

// GET
Router.get("/", async (req, res) => {
  try {
    const data = await User.findAll();
    res.send(data);
  } catch(e) {
      res.status(400);
      return  res.send({
        error: "Houve um problema ao buscar os dados"
      });
  }

});
Router.get("/schedules", async (req, res) => {
  const userid = req.query.id;

  try {
    const data = await User.findOne({where: {id: userid}, include: [Schedules]});
    const schedules = [];

    for(let schedule of data.schedules) {
      schedules.push(await Schedules.findOne({where: {id:schedule.id}, include: [Service]}));
    }

    // console.log(teste);
    res.send(schedules);
  } catch(e) {

      res.status(400);
      return  res.send({
        error: "Houve um problema ao buscar os dados"
      });
  }

});

Router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  console.log(email, password); 

  try {
    const data = await User.findOne({ where: {email} });
    if(data) {
      const hash_status = await bcrypt.compare(password, data.password); 
  
      if(hash_status) {
        const token = await JWT.sign(data.id, JWT_SECRET);
        return res.send({token});
      } else {
        res.status(400);
        return  res.send({
          error: "Dados de login invalidos."
        });
      }
    } else {
      res.status(400);
      return  res.send({
        error: "Dados de login invalidos."
      });
    }
  } catch(e) {
      res.status(400);
      return  res.send({
        error: "Dados de login invalidos."
      });
  }

});

// Cadastro
Router.post("/", async (req, res) => {
  const { username, email, password, address, cpf } = req.body;

  const hash = await bcrypt.hash(password, 10);

  try {
    const data = await User.create({
      username,
      email,
      cpf,
      password: hash,
      address
    });

    res.status(200);

    return res.send({
      username,
      email,
      cpf,
      address,
    });

  } catch(e) {
    res.status(400);
    console.log(e);

    return res.send({
      error: "Erro ao realizar cadastro."
    });
  }

});

module.exports = Router;