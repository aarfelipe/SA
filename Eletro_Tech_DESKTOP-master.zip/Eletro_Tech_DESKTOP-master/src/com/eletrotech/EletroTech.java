
package com.eletrotech;

import eletrotech.gui.MainCard;
import java.io.IOException;

public class EletroTech {

    public static void main(String[] args) throws IOException {
        new MainCard().setVisible(true);
    }

}
