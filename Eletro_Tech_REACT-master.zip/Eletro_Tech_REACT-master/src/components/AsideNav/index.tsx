import React from "react";

import {  Container, NavButton  } from "./styles";

type propTypes = {
    links: [string, JSX.Element | string][]
}

const AsideNav = ({links}:propTypes) => {

    return (
        <Container>
            {links.map((link, index) => (
                <NavButton 
                    selected={false} 
                    key={index}
                    onClick={() => {
                        const dst:string = link[1] as string;
                        if(dst.startsWith("link:")) {
                            window.location.href = dst.split("link:")[1];
                        }


                    }}
                >{link[0]}</NavButton>
            ))}
        </Container>
    );
    
}

export default AsideNav;