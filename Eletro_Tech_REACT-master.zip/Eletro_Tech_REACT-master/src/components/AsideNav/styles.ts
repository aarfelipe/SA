import styled from "styled-components";

export const Container = styled.aside`
    width: 300px;
    height: 70vh;
    background-color: #fff;
    border-right: 1px solid #242729;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    
`;

export const NavButton = styled.button<{selected:boolean}>`
    width: 80%;
    height: 50px;
    background-color: ${({selected}) => selected ? "#24272955" : "#0002"};
    border: none;
    border-radius: 5px;
    cursor: pointer;
    color: #242729;
    font-size: 16px;
    margin: 10px 0;

    &:hover {
        background-color: #24272955;
    }
`;