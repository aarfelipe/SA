import { useState } from "react";
import api from "../../util/api";
import { listDataType } from "../List";

import {
    Container,
    Modal,
    Row,
    Title,
    Text,
    ModalButton
} from "./styles";

type propsType = {
    data: listDataType | undefined,
    visible: boolean
    setVisible: (visible: boolean) => void
}

const DetailsModal = ({data, visible, setVisible}:propsType) => {
    const date = data?.date.substring(0,10).split("-").reverse().join('/');
    const [status, setStatus] = useState("Aguardando pagamento");

    async function payment(id:number) {
        const data = await api.payment(id);

        if(data.status === "Agendado") {
            window.location.reload();
        } else {
            alert("Falha ao realizar pagamento.");
        }
    }

    return (
    <>{visible &&
    <Container>
        <Modal>
            <Title>#{data?.id} - {data?.service.name}</Title>
            <Row>
                <Text bold>Data do agendamento: </Text>
                <Text>{date}</Text>
            </Row>
            <Row>
                <Text bold>Horario de atendimento: </Text>
                <Text>{data?.time}</Text>
            </Row>
            <Row>
                <Text bold>Serviço:  </Text>
                <Text>{data?.service.name}</Text>
            </Row>
            <Row forceColumn>
                <Text bold>Descrição de serviço: </Text>
                <Text>{data?.service.description}</Text>
            </Row>
            <Row>
                <Text bold>Preço do serviço: </Text>
                <Text>{data?.service.value}</Text>
            </Row>
            <Row>
                <Text bold>Status: </Text>
                <Text>{status}</Text>
            </Row>
            {status == "Aguardando pagamento" && 
                <ModalButton onClick={() => payment(data?.id as number)}>FAZER PAGAMENTO</ModalButton>
            }
            <ModalButton onClick={() => setVisible(false)}>Fechar</ModalButton>
        </Modal>
    </Container>}
    </>
)}


export default DetailsModal;