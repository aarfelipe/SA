import styled from "styled-components";

export const Container = styled.div`
    width: 100%;
    height: 100vh;
    background-color: #000b;
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    z-index: 100;
    top: 0;
    left: 0;
`;

export const Modal = styled.div`
    width: 500px;
    height: 500px;
    background-color: #ffff;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;
    padding: 15px 15px 0 15px;
    /* justify-content: center;
    align-items: start; */
`;

export const Row = styled.div<{forceColumn?:boolean}>`
    display: flex;
    flex-direction: ${({forceColumn}) => forceColumn ? "column" : "row"};
    justify-content: start;
    align-items:  flex-start;
`;

export const Title = styled.h5`
    font-size: 20px;
    color: #000;
    margin: 15px 0;
`;

export const Text = styled.p<{bold?:boolean}>`
    font-size: 16px;
    color: #000;
    margin: 10px 0;
    margin-right: 5px;
    font-weight: ${({bold}) => bold ? "bold" : "normal"};
`;

export const ModalButton = styled.button`
    width: 100%;
    height: 40px;
    background-color: #ff6200;
    border-radius: 5px;
    border: none;
    color: #ffffff;
    cursor: pointer;
    &:hover {
        background-color: #b84700;
    }

`;