import React from 'react';

import logo from "../../assets/logo_orange.png";

import {
  Container,
  LogoImage,
  NavContainer,
  NavLink,
} from "./styles";
 
function Footer(): JSX.Element {
  return (
    <Container>
      <LogoImage src={logo} />
      <NavContainer>
        <NavLink>Sobre</NavLink>
        <NavLink>Serviços</NavLink>
        <NavLink>Contato</NavLink>
        <NavLink>Contato</NavLink>
        <NavLink>Entrar</NavLink>
      </NavContainer>
    </Container>
  );
}

export default Footer;