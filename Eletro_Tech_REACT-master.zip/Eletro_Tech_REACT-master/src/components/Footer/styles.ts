import styled from "styled-components";

export const Container = styled.footer`
  width: 100%;
  height: 60vh;
  background-color: #242729;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  padding: 50px 20px;
  margin-top: 100px;
  /* background-color: blue; */
`;

export const NavContainer = styled.nav`
  /* height: 100%; */
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: center;
  /* background-color: red; */
`;

export const NavLink = styled.a`
  width: 100px;
  position: relative;
  text-align: center;
  margin: 0 10px;
  color: #ffffff;
  margin: 10px;
  cursor: pointer;

  &:hover {
    color: #ff6200;
  }

  &:before {
    content: "";
    position: absolute;
    width: 0;
    height: 2px;
    background-color: #ff6200;
    bottom: -5px;
    left: 0;
    transition: all .5s ease-in-out;
  }

  &:hover:before {
    width: 100px;
  }
`;


export const LogoImage = styled.img`
  width: 200px;
`;