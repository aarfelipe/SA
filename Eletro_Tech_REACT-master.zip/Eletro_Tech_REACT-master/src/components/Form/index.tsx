import { useState } from 'react';

import { Container, Input, Label, ErrorMessage, Select,FormText } from "./styles";
import { LogoImage } from "../Header/styles";
import { Text } from "../Hero/styles";

import logo from "../../assets/logo_orange.png";
import { getValue } from '@testing-library/user-event/dist/utils';

type fieldType = {
  label: string,
  type: string,
  placeholder?: string,
  value: string | string[],
  options?:(string|number)[][],
  setter: (value:string) => void,
}

type propsType = {
  style?: "light" | "dark",
  fields: fieldType[],
  submitValue: string,
  submitHandler: (setErrorMessage : React.Dispatch<React.SetStateAction<string>>) => void,
  optionText?: JSX.Element,
}

function Form({ style="dark", fields, submitValue, submitHandler, optionText } : propsType) : JSX.Element {
  const [error, setError] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>("");

  return (
    <Container Style={style}>
      <a href="/" style={{marginBottom: 30}}>
        <LogoImage src={logo} />
      </a>

      {errorMsg &&
        <ErrorMessage>{errorMsg}</ErrorMessage>
      }

      {
        fields.map((field, index) => {
          let component : JSX.Element = <div key={index} style={{width: "100%"}}>
            <Label Style={style}>{field.label}</Label>
            <Input 
              Style={style}
              type={field.type} 
              placeholder={field.placeholder} 
              value={field.value} 
              onChange={value => field.setter(value.target.value)}
              required
            />
          </div>;
          
          if(field.type == "date") {
            component = <div key={index} style={{width: "100%"}}>
              <Label Style={style}>{field.label}</Label>
              <Input 
                Style={style}
                type={field.type} 
                placeholder={field.placeholder} 
                value={field.value} 
                onChange={value => field.setter(value.target.value)}
                max={new Date().toLocaleDateString().replaceAll("/", "-").split("-").reverse().join("-")}
                required
              />
            </div>;
          } else if(field.type == "select") {
            component = <div key={index} style={{width: "100%"}}>
              <Label Style={style}>{field.label}</Label>
              <Select
                Style={style}
                
                onChange={value => field.setter(value.target.value)}
                required
              >
                <option value="deafault" selected >{field.placeholder}</option>
                {field.options?.map((option, index) => 
                  <option value={option[0]}>{option[1]}</option>
                )}
              </Select>
            </div>;
          } else if(field.type == "text-bold") {
            if(!field.value) return;
            component = <div key={index} style={{width: "100%"}}>
              <Label Style={style}>{field.label}</Label>
              <FormText color="#ff6200" Style={style}>{field.value}</FormText>
            </div>;
          } else if(field.type == "text-light") {
            if(!field.value) return;
            component = <div key={index} style={{width: "100%"}}>
              <Label Style={style}>{field.label}</Label>
              <FormText size="16px" Style={style} style={{fontWeight: "lighter"}}>{field.value}</FormText>
            </div>;
          } 

          return component;
        })
      }
      
      <Input 
        type="submit" 
        value={submitValue} 
        onClick={(e) => {
          e.preventDefault();
          submitHandler(setErrorMsg);
        }}
      />

      <Text style={{width: "100%"}}>
        {optionText}
      </Text>

    </Container>
  );
}

export default Form;