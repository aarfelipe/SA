import styled from "styled-components";

export const Container = styled.form<{Style:string}>`
  width: 400px;
  min-height: 500px;
  background-color: ${({Style}) => Style == "light" ? "#ffffff" : "#242729"};
  z-index: 10;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border-radius: 5px;
`;

export const Input = styled.input<{Style?:string}>`
  width: 100%;
  height: 40px;
  background-color: ${({type, Style}) => type == "submit" ? "#ff6200" : (Style == "light" ? "#00000033" : "#ffffff55")};
  border: none;
  border-radius: 5px;
  padding: 0 10px;
  font-size: 20px;
  color: ${({Style}) => Style == "light" ? "#24272" : "#ffffff"};
  transition: all .2s linear;
  margin: 10px 0 25px 0;
  cursor: ${({type}) => type == "submit" ? "pointer" : "text"};

  &::placeholder {
    color: ${({Style}) => Style == "light" ? "#2427255" : "#ffffff66"};
  }

  &:focus {
    border: 2px solid #ff6200;
  }
`;
export const Select = styled.select<{Style?:string}>`
  width: 100%;
  height: 40px;
  background-color: ${({Style}) => Style == "light" ? "#00000033" : "#ffffff55"};
  border: none;
  border-radius: 5px;
  padding: 0 10px;
  font-size: 20px;
  color: ${({Style}) => Style == "light" ? "#24272" : "#ffffff"};
  transition: all .2s linear;
  margin: 10px 0 25px 0;
  cursor: cursor;

  &::placeholder {
    color: ${({Style}) => Style == "light" ? "#2427255" : "#ffffff66"};
  }

  &:focus {
    border: 2px solid #ff6200;
  }
`;

export const Label = styled.label<{Style:string}>`
  color: ${({Style}) => Style == "light" ? "#242729" : "#ffffff"};
  font-size: 20px;
  width: 85%;
`;

export const ErrorMessage = styled.span`
  width: 85%;
  height: 35px;
  line-height: 30px;
  background-color: #ff620022;
  color: #ff6200;
  border: 2px solid #ff6200;
  border-radius: 5px;
  text-align: center;
  font-size: 15px;
  margin-bottom: 20px;
`;

export const Link = styled.a`
  color: #ff6200;
  font-size: 16px;
  width: 85%;
`;

export const FormText = styled.p<{Style:string, size?: string}>`
  width: 100%;
  margin-bottom: 10px;
  text-align: left;
  font-size: ${({size}) => size || "25px"};
  font-weight: bolder;
  color: ${({Style,color}) => color || (Style == "light" ? "#000000" : "#ffffff")};
`;