import React, { useState, useEffect } from 'react';

import logo_white from "../../assets/logo_white.png";
import logo_orange from "../../assets/logo_orange.png";

import api from '../../util/api';

import {
  Container,
  LogoImage,
  NavContainer,
  NavLink,
  NavButton,
} from "./styles";
 
type headerType = {
  opaque?:boolean,
  bgcolor?:string,
  linkcolor?:string,
  linkhover?:string,
  logocolor?:"white" | "orange",
  showDefaultLinks?:true | false
}

function Header({opaque=false,bgcolor="#ffffff",linkcolor="#242729",logocolor="orange",linkhover="#ff6200",showDefaultLinks=true}:headerType): JSX.Element {
  const [bgColor, setBgColor] = useState<string>("#ffffff00");
  const [linkColor, setLinkColor] = useState<string>("#ffffff");
  const [logo, setLogo] = useState<string>(logo_white);
  const [logged, setLogged] = useState<boolean>(false);

  useEffect(() => {
    const token : string | null = localStorage.getItem("token");
    if(token) setLogged(true);
    if(!opaque) {
      window.addEventListener("scroll", e => {
        const y = window.pageYOffset;
        if(y > 10) {      
          setBgColor("#ffffff");
          setLinkColor("#242729");
          setLogo(logo_orange);
        } else {
          setBgColor("#ffffff00");
          setLinkColor("#ffffff");
          setLogo(logo_white);
        }
        
      });
    } else {
      setBgColor(bgcolor);
      setLinkColor(linkcolor);
      setLogo(logocolor=='white'?logo_white:logo_orange);
    }
  }, []);
 
  function logoff() : void {
    localStorage.removeItem("token");
    window.location.reload();
  }
  return (
    <Container color={bgColor}  >
      <NavLink href='/' hover="transparent">
        <LogoImage src={logo} />
      </NavLink>
      <NavContainer>
        {showDefaultLinks &&
          <>
            <NavLink color={linkColor} hover={linkhover} >Sobre</NavLink>
            <NavLink color={linkColor} hover={linkhover} >Serviços</NavLink>
            <NavLink color={linkColor} hover={linkhover} > Contato</NavLink>
            {logged && 
              <>
                <NavLink color={linkColor} hover={linkhover} href="/agendamento"> Fazer agendamento</NavLink>
                <NavLink color={linkColor} hover={linkhover} href="/area-do-cliente" >Area do cliente</NavLink>
              </>
            }
          </>
        }
        {logged ?
          <NavButton role="button" onClick={logoff}>Sair</NavButton>
        : <NavButton href='/login'>Entrar</NavButton>
        }
      </NavContainer>
    </Container>
  );
}

export default Header;