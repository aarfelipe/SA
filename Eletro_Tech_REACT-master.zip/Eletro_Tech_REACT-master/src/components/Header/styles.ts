import styled from "styled-components";

export const Container = styled.header`
  width: 100%;
  height: 80px;
  position: fixed;
  top: 0;
  z-index: 100;
  background-color: ${({color}) => color};
  box-shadow: ${({color}) => color=="#ffffff" ? "0 0 5px #24272955" : "none"};
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
  transition: all .3s ease-in;
`;

export const NavContainer = styled.nav`
  height: 100%;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  /* background-color: red; */
`;

export const NavLink = styled.a<{hover?:string}>`
  min-width: 100px;
  position: relative;
  text-align: center;
  margin: 0 10px;
  color: ${({color}) => color || "#242729"};
  cursor: pointer;

  &:hover {
    color: ${({hover}) => hover || "#ff6200"} !important;
  }

  &:before {
    content: "";
    position: absolute;
    width: 0;
    height: 2px;
    background-color: ${({hover}) => hover || "#ff6200"};
    bottom: -5px;
    left: 0;
    transition: all .5s ease-in-out;
  }

  &:hover:before {
    width: 100%;
  }
`;

export const NavButton = styled.a`
  width: 100px;
  /* height: 100%; */
  /* line-height: 50px; */
  text-align: center;
  margin: 0 10px;
  color: #ffffff;
  padding: 5px;
  background-color: #ff6200;
  cursor: pointer;

  &:hover {
    background-color: #b84700;
  }
`;

export const LogoImage = styled.img`
  width: 200px;
  /* height: 35px; */
`;