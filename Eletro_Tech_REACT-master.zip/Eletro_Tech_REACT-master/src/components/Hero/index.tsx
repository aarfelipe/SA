import React from "react";

import {
  Container,
  Title,
  Text,
  Content
} from "./styles";

function Hero() : JSX.Element {
  return (
    <Container>
      <Content>
        <Title>Eletro Tech Solutions</Title>
        <Text>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae eveniet sequi tempore magni, laboriosam alias maxime eaque quos libero illum similique neque porro architecto labore mollitia, minima magnam. Beatae, optio?</Text>
      </Content>
    </Container>
  );
}

export default Hero;