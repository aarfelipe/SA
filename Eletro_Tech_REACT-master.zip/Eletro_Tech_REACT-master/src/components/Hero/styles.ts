import styled from "styled-components";

import heroImage from "../../assets/eletricista2.jpg";

export const Container = styled.main<{ image?: boolean}>`
  width: 100%;
  min-height: 100vh;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  background-image: ${({image=true}) => image && `url(${heroImage})`};
  background-size: cover;
  background-color: #242729;
  padding: 50px 0;

  &::before {
    content: "";
    position: absolute;
    width: 100%;
    height: 100vh;
    background-color: ${({color}) => color && color+"55" || "#00000077"};
    z-index: 1;
  }
`;

export const Title = styled.h1`
  font-size: 80px;
  color: #ffffff;
  /* font-family: 'Noto Sans', sans-serif; */
  font-weight: bold;
  /* text-shadow: 0px 0px 5px #000000aa; */
`;

export const Text = styled.p`
  width: 50%;
  /* height: 100%; */
  /* line-height: 50px; */
  text-align: justify;
  color: #ffffff;
`;

export const Content = styled.section`
  width: 100%;

  z-index: 2;
  padding: 0 50px;
`;