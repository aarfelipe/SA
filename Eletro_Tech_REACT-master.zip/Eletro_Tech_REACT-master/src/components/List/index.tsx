import React, { useState } from "react";
import DetailsModal from "../DetailsModal";

import {
  Container,
  Title,
  Text,
  Content,
  Row,
  Info,
  Status,
  Button
} from "./styles";

export type listDataType = {
  id: number,
  title: string,
  status: string,
  service: {
    name: string
    description: string
    value: string
  },
  date: string,
  time: string,
}

type propsType = {
  data : listDataType[],
}

function List({data}:propsType) : JSX.Element {
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [modalData, setModalData] = useState<listDataType>();

  return (
    <>
    <DetailsModal visible={modalVisible} setVisible={setModalVisible} data={modalData}/>
    <Container>
      <Content>
        {data.map((row, index) => {
          const date = row.date.substring(0,10).split("-").reverse().join('/');


          return( 
            <Row>
              <Info>
                <Title>#{row.id} {row.service.name}</Title>
                <div style={{width:"100%", display: 'flex', justifyContent: "space-between"}}>
                  <Text>{date} - {row.time}</Text>
                  <Button onClick={() => {
                    setModalData(data[index]);
                    setModalVisible(true)
                  }}>Ver detalhes</Button>
                </div>
              </Info>
              <Status>
                <Title>Status</Title>
                <Text color="green" style={{textAlign: "center"}}>{row.status}</Text>
              </Status>
            </Row>
          )
      })}
      </Content>
    </Container>
    </>
  );
}

export default List;