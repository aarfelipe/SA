import styled from "styled-components";

import heroImage from "../../assets/eletricista2.jpg";

export const Container = styled.main<{ image?: boolean}>`
  width: 100%;
  height: 100vh;
  overflow-y: scroll;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  background-size: cover;
  background-color: #ffffff;
  /* padding-top: 150px; */
`;

export const Title = styled.h1`
  font-size: 20px;
  color: #242729;
  /* font-family: 'Noto Sans', sans-serif; */
  font-weight: bold;
  /* text-shadow: 0px 0px 5px #000000aa; */
`;

export const Text = styled.p`
  /* height: 100%; */
  /* line-height: 50px; */
  font-size: 16px;
  text-align: justify;
  color: ${({color}) => color || "#242729"};
`;

export const Content = styled.section`
  width: 100%;

  z-index: 2;
  padding: 0 50px;
`;

export const Row = styled.div<{Style?:string}>`
  display: flex;
  justify-content: center;
  align-items: flex-start;

  width:100%;
  height: 80px;
  /* background-color: #00000025; */
  border: none;
  border-radius: 5px;
  color: #242729;
  margin-bottom: 30px;
  /* margin: 10px 0 25px 0; */
  cursor: pointer;
`;

export const Info = styled.div<{Style?:string}>`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-start;

  width:80%;
  height: 80px;
  background-color: #00000025;
  border: none;
  border-radius: 5px;
  font-size: 20px;
  color: #242729;
  transition: all .2s linear;
  padding: 10px;
  cursor: pointer;

  &:hover {
    background-color: #00000030;
  }
`;

export const Status = styled.div<{Style?:string}>`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  width:20%;
  height: 80px;
  border: none;
  border-radius: 5px;
  padding: 0 10px;
  font-size: 20px;
  color: #242729;
  transition: all .2s linear;
  cursor: pointer;

`;

export const Button = styled.button`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  width:100px;
  height: 25px;
  border: none;
  border-radius: 5px;
  padding: 0 10px;
  font-size: 12px;
  color: #fff;
  background-color: #ff6200;
  transition: all .2s linear;
  cursor: pointer;

  &:hover {
    background-color: #b84700;
  }

`;