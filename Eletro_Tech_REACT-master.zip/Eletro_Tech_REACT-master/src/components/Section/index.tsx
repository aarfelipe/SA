import React from "react";

import {
  Container,
  Title,
  Text,
  Content,
  WellcomeText
} from "./styles";

type propsType = {
  style?: "dark" | "light",
  wellcomeText: string,
  title: string,
  text?: string,
  Component?: JSX.Element
}

function Section({
  style="light",
  wellcomeText,
  title,
  text,
  Component
} : propsType) : JSX.Element {
  return (
    <Container 
      style={{backgroundColor: style === "dark" ? "#242729" : "#ffffff"}}
    >
      <Content>
        <WellcomeText 
          style={{color: style === "dark" ? "#ffffff" : "#242729"}}
        >{wellcomeText}</WellcomeText>
        <Title
          style={{color: style === "dark" ? "#ffffff" : "#242729"}}
        >{title}</Title>
        {text &&
        <Text
          style={{color: style === "dark" ? "#ffffff" : "#242729"}}
        >{text}</Text>}
        {Component &&
          (Component)}
      </Content>
    </Container>
  );
}

export default Section;