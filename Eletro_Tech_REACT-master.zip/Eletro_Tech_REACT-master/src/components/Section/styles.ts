import styled from "styled-components";

import heroImage from "../../assets/eletricista2.jpg";

export const Container = styled.section`
  width: 100%;
  height: 65vh;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  background-color: #ffffff;
`;

export const Title = styled.h1`
  font-size: 50px;
  color: #242729;
  text-align: center;
  margin: 30px 0;
  font-weight: bold;
`;

export const WellcomeText = styled.p`
  font-size: 15px;
  font-weight: bolder;
  text-transform: uppercase;
  text-align: center;
  color: #242729;
`;

export const Text = styled.p`
  font-size: 24px;
  font-weight: lighter;
  text-align: center;
  color: #242729;
`;

export const Content = styled.section`
  width: 75%;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  padding: 50px;
`;