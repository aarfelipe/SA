import React from "react";
import { IconType } from "react-icons";

import {
  Container,
  Title,
  Text,
} from "./styles";

type propsType = {
  Icon: IconType,
  title: string,
  description: string
}

function ServiceItem({
  Icon,
  title,
  description
}: propsType) : JSX.Element {
  return (
    <Container>
      <Icon color="#ffffff" size={70}/>
      <Title>{title}</Title>
      <Text>{description}</Text>
    </Container>
  );
}

export default ServiceItem;