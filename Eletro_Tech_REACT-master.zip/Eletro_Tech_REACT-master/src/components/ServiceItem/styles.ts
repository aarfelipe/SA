import styled from "styled-components";

import heroImage from "../../assets/eletricista2.jpg";

export const Container = styled.section`
  width: 300px;
  height: 315px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  background-color: #ff6200;
  margin: 0 10px;

  &:hover {
    background-color: #b84700;
  }
`;

export const Title = styled.h1`
  font-size: 20px;
  color: #fff;
  text-align: center;
  margin: 30px 0;
  font-weight: bold;
`;

export const Text = styled.p`
  font-size: 16px;
  font-weight: lighter;
  text-align: center;
  color: #fff;
`;