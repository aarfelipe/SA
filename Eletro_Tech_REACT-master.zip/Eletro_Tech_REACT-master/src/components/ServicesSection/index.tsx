import React from "react";
import { IconType } from "react-icons";

import { FaBuilding, FaBolt, FaClipboard } from "react-icons/fa";

import ServiceItem from "../ServiceItem";

import {
  Container,
  Title,
  Text,
  Content,
  CardsSection,
  WellcomeText
} from "./styles";

function ServicesSection() : JSX.Element {
  return (
    <Container>
      <Content>
        <WellcomeText>Conheça nossos serviços</WellcomeText>
        <Title>Oferecemos soluções completas para sua empresa</Title>
        <CardsSection>
          <ServiceItem
            title="Lorem Ipsum"
            description="Lorem, ipsum dolor sit amet consectetur adipisicing elit.Lorem, ipsum dolor sit amet consectetur adipisicing elit."
            Icon={FaBuilding}
          />
          <ServiceItem
            title="Lorem Ipsum"
            description="Lorem, ipsum dolor sit amet consectetur adipisicing elit.Lorem, ipsum dolor sit amet consectetur adipisicing elit."
            Icon={FaBolt}
          />
          <ServiceItem
            title="Lorem Ipsum"
            description="Lorem, ipsum dolor sit amet consectetur adipisicing elit.Lorem, ipsum dolor sit amet consectetur adipisicing elit."
            Icon={FaClipboard}
          />
        </CardsSection>
      </Content>
    </Container>
  );
}

export default ServicesSection;