import Header from '../../components/Header';
import Hero from '../../components/Hero';
import Section from '../../components/Section';
import ServicesSection from '../../components/ServicesSection';
import List from '../../components/List';

import { Text } from "../../components/Section/styles"
import { NavButton, NavLink } from "../../components/Header/styles"
import Footer from '../../components/Footer';
import { useEffect } from 'react';

import AsideNav from '../../components/AsideNav';

import api, { requestType } from '../../util/api';
import { Wrapper } from './styles';
import Schedules from '../Schedules';
import { idText } from 'typescript';

function ClientArea() : JSX.Element {
  const orangeText = {color: "#ff6200", marginTop: 20}

  // useEffect(() => {
  //   const token : string | null = localStorage.getItem("token");
  //   if(!token) window.location.href ="/login";


  //   api.login("arthur@email", "teste");
  // }, []);

  const data = [{
    title: "teste"
  }]

  return (
    <>
      <Header opaque={true} bgcolor="#ff6200" linkcolor='#ffffff' logocolor='white' linkhover='#ffffff' showDefaultLinks={false}/>
      <Wrapper>
        <>
          <AsideNav 
            links={[
              ["Agendamentos", "Schedules"],
              ["Novo agendamento", "link:/agendamento"],
            ]}
          />
          <Schedules />
        </>
      </Wrapper>
    </>
    
  );
}

export default ClientArea;