import styled from "styled-components";

export const Wrapper = styled.div`
    padding-top: 80px;
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: start;
    align-items: center;
`; 