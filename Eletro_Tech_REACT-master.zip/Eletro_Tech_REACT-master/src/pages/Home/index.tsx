import Header from '../../components/Header';
import Hero from '../../components/Hero';
import Section from '../../components/Section';
import ServicesSection from '../../components/ServicesSection';

import { Text } from "../../components/Section/styles"
import { NavButton, NavLink } from "../../components/Header/styles"
import Footer from '../../components/Footer';
import { useEffect } from 'react';

import api, { requestType } from '../../util/api';

function Home() : JSX.Element {
  const orangeText = {color: "#ff6200", marginTop: 20}

  // useEffect(() => {
  //   api.login("arthur@email", "teste");
  // }, []);

  return (
    <>
      <Header />
      <Hero />
      <Section
        wellcomeText="Seja bem-vindo a Eletro Tech"
        title="Soluções que a sua empresa precisa"
        text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae eveniet sequi tempore magni, laboriosam alias maxime eaque quos libero illum similique neque porro architecto labore mollitia, minima magnam. Beatae, optio?"
      />
      <ServicesSection />
      <Section
        style="dark"
        wellcomeText="Contato"
        title="Entre em contato conosco e tire todas as suas duvidas"
        Component={(
          <>
            <Text style={orangeText}>E-mail: eletrotech@gmail.com</Text>
            <Text style={orangeText}>Telefone: (31) 9 1234-5678</Text>
          </>
        )}
      />
      <Section
        wellcomeText="Agendamento"
        title="Faça o agendamento de um serviço agora mesmo"
        text="Para fazer um agendamento você precisa ter uma conta"
        Component={(
          <>
            <NavButton style={{margin: 20}}>Criar conta</NavButton>
            <Text>Ou</Text>
            <NavLink style={{margin: 20}}>Fazer login</NavLink>
          </>
        )}
      />
      <Footer />
    </>
    
  );
}

export default Home;