import { useEffect, useState } from 'react';

import api from '../../util/api';

import { Link } from "../../components/Form/styles";
import Form from '../../components/Form';

import { Container } from '../../components/Hero/styles';


function Login() : JSX.Element {
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");

  useEffect(() => {
    const token : string | null = localStorage.getItem("token");
    if(token) window.location.replace("/");
  }, []);

  async function login(setErrorMsg:React.Dispatch<React.SetStateAction<string>>) {
    const success : boolean = await api.login(email, password);
    if(success) window.location.replace("/");
    else setErrorMsg("Dados de login invalidos!");
  }

  return (
    <Container style={{alignItems: "center"}} image={false} color="#242729">
      <Form 
        submitValue='Fazer Login'
        submitHandler={login}
        optionText={<>
          Não tem uma conta?&nbsp;&nbsp;<Link href='/cadastro'>Fazer cadastro</Link>
        </>}
        fields={[
          {
            label: "E-mail:",
            type: "email",
            placeholder: "Informe seu e-mail...",
            value: email,
            setter: setEmail
          },
          {
            label: "Senha:",
            type: "password",
            placeholder: "Informe sua senha...",
            value: password,
            setter: setPassword
          },
        ]}
      />
    </Container>
    
  );
}

export default Login;