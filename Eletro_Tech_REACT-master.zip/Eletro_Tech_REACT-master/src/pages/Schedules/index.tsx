import Header from '../../components/Header';
import Hero from '../../components/Hero';
import Section from '../../components/Section';
import ServicesSection from '../../components/ServicesSection';
import List from '../../components/List';

import { Text, WellcomeText } from "../../components/Section/styles"
import { Container  } from "./styles"
import Footer from '../../components/Footer';
import { useEffect, useState } from 'react';

import api, { requestType } from '../../util/api';

function Schedules() : JSX.Element {
  type scheduleData = {

  }
  const [data, setData] = useState([]);


  useEffect(() => {

    (async () => {
      
      const request_data = await api.getUserSchedules();
      setData(request_data);
      console.log(request_data);
      
    })();
  }, []);



  return (
    <Container>
      <WellcomeText 
          style={{color: "#242729", textAlign: "left", width: "fit-content", margin: 20}}
        >Agendamentos</WellcomeText>
      {/* <Section
        style='dark'
        wellcomeText="Seja bem-vindo a Eletro Tech"
        title="Soluções que a sua empresa precisa"
        text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae eveniet sequi tempore magni, laboriosam alias maxime eaque quos libero illum similique neque porro architecto labore mollitia, minima magnam. Beatae, optio?"
      /> */}
      <List data={data} />
    </Container>
    
  );
}

export default Schedules;