import { useEffect, useState } from 'react';

import api from '../../util/api';

import { Link } from "../../components/Form/styles";
import Form from '../../components/Form';

import { Container } from '../../components/Hero/styles';
import Header from '../../components/Header';



function Scheduling() : JSX.Element {
  type hourOptions = "Manhã - 8h as 13h" | "Tarde - 14h as 19h";

  type serviceType = {
    id: number,
    name: string,
    description: string,
    value: string
  }

  const [address, setAddress] = useState<string>("");
  const [date, setDate] = useState<string>("");
  const [hour, setHour] = useState<string>("Manhã - 8h as 13h");
  const [services, setServices] = useState<serviceType[]>([]);
  const [selectedService, setSelectedService] = useState<number>(0);
  const [value, setValue] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [options, setOptions] = useState<(string|number)[][]>([["",""]]);

  async function getServices() {
    return await api.getServices();
  }

  useEffect(() => {

    const token : string | null = localStorage.getItem("token");
    if(!token) window.location.replace("/login");

    (async () => {
      const data = await getServices();
      setServices(data);
      let options__:(string|number)[][] = [];
      data.forEach((service:{name: string}, index:number) => {
        options__.push([index, service.name]);
      });
      setOptions(options__);
    })();
  }, []);

  async function createSchedule(setErrorMsg:React.Dispatch<React.SetStateAction<string>>) {
    
    if(!hour || !date || !address || !value) 
      return setErrorMsg("Preencha todos os campos");
    
    const success : boolean = await api.createSchedule({
      address,
      date,
      time:hour,
      service_id: selectedService
    });
    if(success) window.location.href = "/area-do-cliente";
    else setErrorMsg("Houve um problema ao criar o agendamento");
  }

  function selectService(index:string|number) {
    if(typeof index == "string") index = parseInt(index);
    setSelectedService(services[index].id);
    setDescription(services[index].description);
    setValue(services[index].value);
  }

  return (
    <>
      <Header logocolor='orange' opaque />
      <Container style={{
          height: "auto",
          alignItems: "center",
          justifyContent: "flex-start",
          backgroundColor:"#ffffff",
          paddingTop: 100
        }} 
        image={false} 
        color="#ffffff"
      >
        <Form 
          style="light"
          submitValue='Fazer agendamento'
          submitHandler={createSchedule}
          fields={[
            {
              label: "Endereço:",
              placeholder: "Informe o endereço:",
              setter: setAddress,
              type: "text",
              value: address
            },
            {
              label: "Data:",
              placeholder: "Informe a data:",
              setter: setDate,
              type: "date",
              value: date
            },
            {
              label: "Horario:",
              placeholder: "Informe o horário:",
              setter: setHour,
              type: "select",
              value: "",
              options: [["Manhã - 8h as 13h","Manhã - 8h as 13h"],["Tarde - 14h as 19h","Tarde - 14h as 19h"]]
            },
            {
              label: "Serviço:",
              placeholder: "Informe o serviço:",
              setter: selectService,
              type: "select",
              value: "",
              options
            },
            {
              label: "Descrição:",
              setter: setValue,
              type: "text-light",
              value: description
            },
            {
              label: "Valor:",
              setter: setValue,
              type: "text-bold",
              value: value
            },
          ]}
        />
      </Container>
    </>
  );
}

export default Scheduling;