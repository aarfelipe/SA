import { useState, useEffect } from "react";

import { Link } from "../../components/Form/styles";
import Form from '../../components/Form';

import { Container } from '../../components/Hero/styles';
import api from "../../util/api";


function SignUp() : JSX.Element {
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [name, setName] = useState<string>("");
  const [cpf, setCpf] = useState<string>("");
  const [address, setAddress] = useState<string>("");

  useEffect(() => {
    const token : string | null = localStorage.getItem("token");
    if(token) window.location.replace("/");
  }, []);

  async function signup(setErrorMsg:React.Dispatch<React.SetStateAction<string>>) {
    const values : string[]= [email, password, name, address];
    let error :boolean = false; 
    values.forEach(value => {
      if(!value) error = true;        
    });

    if(error) return setErrorMsg("Preencha todos os campos!");

    const success : boolean = await api.signup(email, password, name, address, cpf);
    if(success) window.location.replace("/login");
    else setErrorMsg("Houve um erro realizar o cadastro!");
  }

  return (
    <Container style={{alignItems: "center"}} image={false} color="#242729">
      <Form 
        submitValue='Fazer cadastro'
        submitHandler={signup}
        optionText={<>
          Já tem uma conta?&nbsp;&nbsp;<Link href='/login'>Fazer Login</Link>
        </>}
        fields={[
          {
            label: "Nome:",
            type: "text",
            placeholder: "Informe seu nome...",
            value: name,
            setter: setName
          },
          {
            label: "CPF:",
            type: "text",
            placeholder: "Informe seu CPF...",
            value: cpf,
            setter: setCpf
          },
          {
            label: "Endereço:",
            type: "text",
            placeholder: "Informe seu Endereço...",
            value: address,
            setter: setAddress
          },
          {
            label: "E-mail:",
            type: "email",
            placeholder: "Informe seu e-mail...",
            value: email,
            setter: setEmail
          },
          {
            label: "Senha:",
            type: "password",
            placeholder: "Informe sua senha...",
            value: password,
            setter: setPassword
          },
        ]}
      />
    </Container>
    
  );
}

export default SignUp;