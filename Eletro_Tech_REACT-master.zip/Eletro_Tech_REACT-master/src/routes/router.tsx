import React from "react";

import { createBrowserRouter, Router } from "react-router-dom";

import Home from "../pages/Home";
import Login from "../pages/Login";
import SignUp from "../pages/SignUp"; 
import Scheduling from "../pages/Scheduling"; 
import Schedules from "../pages/Schedules"; 
import ClientArea from "../pages/ClientArea"; 

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />
  },
  {
    path: "/login",
    element: <Login />
  },
  {
    path: "/cadastro",
    element: <SignUp />
  },
  {
    path: "/agendamento",
    element: <Scheduling />
  },
  {
    path: "/area-do-cliente",
    element: <ClientArea />
  },
]);

export default router; 