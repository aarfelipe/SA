export type requestType = {
  url: string, 
  method?: "GET" | "POST" | "PUT" | "DELETE", 
  headers?: [string, string][], 
  body?: string
}

const api = {
  async request({
    url, 
    method="GET", 
    headers=[["Content-Type","application/json"]], 
    body
  } : requestType) {
    const request : requestType = {url, method, headers};
    if(body) request.body = body;

    const response = await fetch(url, request);

    const json = await response.json();
    console.log(json);
    return json;
  },
  async login(email: string, password: string) : Promise<boolean> {
    localStorage.removeItem("token");
    const request : requestType = {
      url: "http://54.207.200.19:8080/users/login",
      method: "POST",
      body: JSON.stringify({email, password})
    }
    const response = await this.request(request);
    if(response.token) {
      localStorage.setItem("token", response.token);
      return true;
    } else return false;
  },
  async signup(email: string, password: string, name: string, address: string, cpf: string) : Promise<boolean> {
    const request : requestType = {
      url: "http://54.207.200.19:8080/users",
      method: "POST",
      body: JSON.stringify({email, password, username:name, address, cpf})
    }
    const response = await this.request(request);

    if(response.username) return true;
    else return false;
  },
  async getServices() {
    const request : requestType = {url: "http://54.207.200.19:8080/services/available"};
    const data = this.request(request);
    return data;
  },
  async createSchedule({address, date, time, service_id}:{address:string, date:string, time:string, service_id:number}) {
    const jwt = localStorage.getItem("token");
    if(!jwt) return false;
    const user_id = atob(jwt.split(".")[1]);    
    // const user_id = 1;    

    const request : requestType = {
      url: "http://54.207.200.19:8080/schedules",
      method: "POST",
      body: JSON.stringify({
        address, 
        date, 
        time, 
        service_id, 
        user_id, 
        status: "Aguardando pagamento"
      })
    }
    const data = this.request(request);
    return data;
  },
  async getUserSchedules() {
    const jwt = localStorage.getItem("token");
    if(!jwt) return false;
    const user_id = atob(jwt.split(".")[1]);    
    // const user_id = 1;    

    const request : requestType = {
      url: `http://54.207.200.19:8080/users/schedules?id=${user_id}`,
    }
    const data = this.request(request);
    return data;
  },
  async payment(scheduleId:number) {
    const jwt = localStorage.getItem("token");
    if(!jwt) return false;
    const user_id = atob(jwt.split(".")[1]);    
    // const user_id = 1;    

    const request : requestType = {
      url: `http://54.207.200.19:8080/schedules/${scheduleId}/payment`,
      method: "POST"
    }
    const data = this.request(request);
    return data;
  }
}

export default api;